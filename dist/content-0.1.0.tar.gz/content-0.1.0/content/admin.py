from django.contrib import admin

# Register your models here.
from content.models import Block

admin.site.register(Block)
